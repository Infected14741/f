git clone https://github.com/Infected14741/u.git
clear
cd u
unzip u.zip
clear
cd u
mv infected.sh /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
rm -rf u
rm -rf AOFSFOF.sh
sh infected.sh