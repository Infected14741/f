#!/bin/bash
#version 3.0
#HAK CIPTA MILIK INFECTED_AOFSFOF

git clone https://github.com/Infected14741/u.git
clear
cd u
mv u.zip /$HOME/CMN-BruteforceIG
cd 
cd CMN-BruteforceIG
unzip u.zip
clear
sh Infected.sh